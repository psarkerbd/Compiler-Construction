#include<bits/stdc++.h>
using namespace std;

int main()
{
	//cout << "hello world";
	freopen("input_file.txt" , "r" , stdin);
	string s;
	getline(cin , s);
	//cout << s << "\n";
	
	return 0;
}