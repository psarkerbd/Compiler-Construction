/*
@Author: Pranta Sarker
*/

import java.util.*;
import java.math.*;
import java.io.*;

class code
{
	public static void main(String [] args)
	{
		try
		{
			File flin = new File("input_file.txt");
			BufferedReader br = new BufferedReader(new FileReader(flin));
			String str = "";
			str = br.readLine();
			//System.out.println(str);
			br.close();
			
		}catch(IOException ex)
		{
			System.out.println("File not found !");
		}
	}
}