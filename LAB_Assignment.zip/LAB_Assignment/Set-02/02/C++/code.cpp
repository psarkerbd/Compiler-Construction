/*
@Author: Pranta Sarker

*/

#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	
	freopen("input_file.txt" , "r" , stdin);
	freopen("output_file.txt" , "w" , stdout);
	
	getline(cin , s);
	cout << s << "\n";
	
	return 0;
}