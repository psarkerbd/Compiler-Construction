/*
 *@Author: Pranta Sarker
 *
 **/
 
 import java.util.*;
 import java.io.*;
 
 public class code
 {
 	public static void main (String[] args)
 	{
 		try
 		{
 			File flin = new File("input_file.txt");
 			FileReader freader = new FileReader(flin);
 			BufferedReader br = new BufferedReader(freader);
 			String str = br.readLine();
 			
 			String [] arr = new String[1001];
 			
 			int i , totalFreq = 0, words = 0 , fl = 1 , arrlen=0;
 			
 			String makestr = "";
 			
 			Map<String, Integer>mp = new HashMap<String, Integer>();
 			
 			for(i=0; i<str.length(); i++)
 			{
 				char ch = str.charAt(i);
 				
 				if(Character.isLetter(ch))
 				{
 					if(fl == 1)
 					{
 						makestr+=Character.toString(ch);
 						
 						fl = 0;
 						
 						words+=1;
 					}
 					
 					else
 					{
 						makestr+=Character.toString(ch);
 					}
 				}
 				
 				else
 				{
 					fl = 1;
 					
 					if(makestr != "")
 					{
 						arr[arrlen++] = makestr;
 						Integer count = mp.get(makestr);
 						int newcnt = (count == null) ? 1 : count+1;
 						mp.put(makestr , newcnt);
 					}
 					
 					makestr = "";
 				}
 			}
 			
 			totalFreq = 0;
 			
 			for(i=0; i<arrlen; i++)
 			{
 				totalFreq+=mp.get(arr[i]);
 				
 				System.out.println(arr[i] + "->" + mp.get(arr[i]));
 			}
 			
 			System.out.println("Total Words: " + words + "\nTotal Frequency: " + totalFreq);
 			
 			br.close();
 				
 		}catch(IOException ex)
 		{
 			System.out.println("File not found !");
 		}
 	}
 }