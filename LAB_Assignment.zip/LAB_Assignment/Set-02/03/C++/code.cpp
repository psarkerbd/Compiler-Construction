///*
//@Author: Pranta Sarker
//*/
//
//#include<bits/stdc++.h>
//using namespace std;
//
//typedef map<string, int>mpsi;
//
//int main()
//{
//	freopen("input_file.txt" , "r" , stdin);
//
//	mpsi mp;
//	string s , makestr="" , maxstr="";
//
//	getline(cin , s);
//
//	int len = s.length() , i , freq=0 , word = 0;
//
//	for(i=0; i<len; i++)
//	{
//		//makestr = "";
//
//		if(isalpha(s[i]))
//		{
//			word = 1;
//			makestr+=s[i];
//		}
//
//		else
//		{
//			if(word)
//			{
//				mp[makestr]++;
//				//cout << makestr << "- " << mp[makestr] << "\n";
//
//				if(mp[makestr] > freq)
//				{
//					freq = mp[makestr];
//					maxstr = makestr;
//				}
//			}
//
//			word = 0;
//			makestr = "";
//		}
//	}
//
//	cout << maxstr << "-" << freq << "\n";
//
//	return 0;
//}


#include<bits/stdc++.h>
using namespace std;

typedef map<string, int>mpsi;
typedef vector<string>vs;

int main()
{
	freopen("input_file.txt" , "r" , stdin);
	mpsi mp;
	vs v;
	string str , makestr="";
	getline(cin , str);
	int i=0 , words=0 , fl = 1 , totalFreq=0;

	for(i=0; i<str.length(); i++)
	{
		if(isalpha(str[i]))
		{
			if(fl == 1)
			{
				makestr+=str[i];

				words+=1;

				fl = 0;
			}

			else
			{
				makestr+=str[i];
			}
		}

		else
		{
			fl = 1;
			if(makestr != "")
			{
				mp[makestr]++;
				v.push_back(makestr);
			}

			makestr="";
		}
	}

	for(i=0; i<v.size(); i++)
	{
		totalFreq+=mp[v[i]];

		cout << v[i] << "->" << mp[v[i]] << "\n";
	}

	cout << "Total Words: " << words << "\n" << "Total Frequency: " << totalFreq << "\n";
	cout << "Except Space: " << totalFreq - mp[" "] << "\n";

	return 0;
}
