/**
 * @(#)code.java
 *
 *
 * @author Pranta Sarker
 * 
 */

import java.util.*;
import java.io.*;

public class code
{
	public static void main (String[] args)
	{
		try
		{
			File flin = new File("input_file.txt");
			FileReader freader = new FileReader(flin);
			BufferedReader br = new BufferedReader(freader);
			String str = br.readLine();
			//str += str.valueOf('\n');
			
			//System.out.println(str);
			
			int cnt = 0 , i=0 , word = 1;
			String makestr="";
			int mxfrq = 0;
			String mxstr = "" , tmp="";
			
			Map<String, Integer>mp = new HashMap<String, Integer>();
			
			for(i=0; i<str.length(); i++)
			{
				char ch = str.charAt(i);
				
				if(Character.isLetter(ch) && ch != ' ')
				{
					if(word == 1)
					{
						
						makestr += Character.toString(ch);
						//System.out.print(makestr + "; ");
						//System.out.println(ch);
						
						//word = 0;
					}
				}
				
				else
				{
					
					word = 0;
					
					if(word == 1 && ch != ' ')
					{
						makestr += Character.toString(ch);
					}
					
					if(makestr != "")
					{
						Integer count = mp.get(makestr);
						cnt = (count == null) ? 1 : count + 1;
						mp.put(makestr , cnt);
						
						if(mxfrq < mp.get(makestr))
						{
							mxfrq = mp.get(makestr);
							mxstr = makestr;
						}
						
						//System.out.println(makestr + "->" + mp.get(makestr));
					}
					
					makestr = "";
					word = 1;
				}
			}
			
			//System.out.println(makestr);
			
			System.out.println(mxstr + "->" + mxfrq);
			
			br.close();
			
		}catch(IOException ex)
		{
			System.out.println("File not found !");
		}
	}
}