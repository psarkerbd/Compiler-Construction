/*
 *@Author: Pranta Sarker
 *
 **/

 #include<bits/stdc++.h>
 using namespace std;
 
 typedef map<string, int>mpsi;
 
 int main()
 {
	 freopen("input_file.txt" , "r" , stdin);
	 string s , makestr="";
	 mpsi mp;
	 getline(cin , s);
	 int fl = 1, uniqWords = 0 , i;
	 
	 for(i=0; i<s.length(); i++)
	 {
		 if(isalpha(s[i]))
		 {
			 if(fl == 1)
			 {
				 makestr += s[i];
				 
				 fl = 0;
			 }
			 
			 else
			 {
				 makestr += s[i];
			 }
		 }
		 
		 else
		 {
			 fl = 1;
			 
			 if(makestr != "")
			 {
				 mp[makestr]++;
				 
				 if(mp[makestr] == 1)
				 {
					 uniqWords+=1;
				 }
			 }
			 
			 makestr = "";
		 }
	 }
	 
	 cout << "Total Unique Words: " << uniqWords << "\n";
	 
	 return 0;
 }