/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

public class code
{
	public static void main (String[] args)
	{
		try
		{
			File flin = new File("input_file.txt");
			FileReader freader = new FileReader(flin);
			BufferedReader br = new BufferedReader(freader);
			String str = br.readLine() , makestr="";
			
			int uniqWords = 0 , i , fl=1;
			
			Map<String, Integer>mp = new HashMap<String, Integer>();
			
			for(i=0; i<str.length(); i++)
			{
				char ch = str.charAt(i);
				
				if(Character.isLetter(ch))
				{
					if(fl == 1)
					{
						makestr += Character.toString(ch);
						
						fl=0;
					}
					
					else
					{
						makestr += Character.toString(ch);
					}
				}
				
				else
				{
					fl = 1;
					
					if(makestr != "")
					{
						Integer count = mp.get(makestr);
						int cnt = (count == null) ? 1 : count + 1;
						
						mp.put(makestr , cnt);
						
						if(mp.get(makestr) == 1)
						{
							uniqWords += 1;
						}
					}
					
					makestr = "";
				}
			}
			
			System.out.println("Unique Words: " + uniqWords);
			
			br.close();
			
		}catch(IOException ex)
		{
			System.out.println("File not found !");
		}
	}
}
