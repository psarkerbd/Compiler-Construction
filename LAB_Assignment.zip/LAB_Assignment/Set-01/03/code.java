/*
*@Author: Pranta Sarker
*/

import java.util.*;
public class code
{
	public static void main(String [] args)
	{
		Scanner in = new Scanner(System.in);
		
		String str;
		
		System.out.println("Enter a String: ");
		
		str = in.nextLine();
		
		System.out.println("You have Entered: " + str);
	}
}