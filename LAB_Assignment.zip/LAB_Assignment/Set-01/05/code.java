/*
 *@Author: Pranta Sarker
 **/
 
 import java.util.*;
 import java.io.*;
 
 public class code
 {
 	public static void main (String[] args)
 	{
 		try
 		{
 			InputStreamReader inpreader = new InputStreamReader(System.in);
 			BufferedReader br = new BufferedReader(inpreader);
 			System.out.print("Enter first string: ");
 			String str1 = br.readLine();
 			
 			System.out.print("Enter second string: ");
 			String str2 = br.readLine();
 			
 			//System.out.println(str1 + " " + str2);
 			String concaterate = str1 + str2;
 			
 			System.out.println("Concatenated String: " + concaterate);
 			br.close();
 			
 			
 		}catch(IOException ex)
 		{
 			System.out.println("Problem occured");
 		}
 	}
 }