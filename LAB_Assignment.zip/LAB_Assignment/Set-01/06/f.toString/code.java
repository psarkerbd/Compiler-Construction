/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		//out dem = new out();
		
		int x = 12;
		String str = Integer.toString(x);
		
		System.out.format("%s was an integer\n" , str); // integer to string
		
		char ch = 'x';
		
		str = Character.toString(ch); // character to string
		
		System.out.format("%s was a character\n" , str);
		
		float f = (float)50.85; // float to string
		
		str = Float.toString(f);
		
		System.out.format("%s was a floating number\n" , str);
	}
}