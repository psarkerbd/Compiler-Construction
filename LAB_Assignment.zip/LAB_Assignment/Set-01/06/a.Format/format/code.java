/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

public class code
{
	public static void main (String[] args)
	{
		try
		{
			InputStreamReader inpreader = new InputStreamReader(System.in);
			BufferedReader br  = new BufferedReader(inpreader);
			String str ="";
			System.out.printf("Enter a String: ");
			str = br.readLine();
			str = str.format("You have typed: %s\n" , str);
			System.out.printf(str);
			
			//System.out.format("You have typed: %s\n" , str); // this is the another format
			
			
		}catch(IOException ex)
		{
			System.out.printf("Problem occured\n");
		}
	}
}