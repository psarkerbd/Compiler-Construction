/*
 *@Author: Pranta Sarker
 **/
 
 import java.util.*;
 import java.io.*;
 
 public class code
 {
 	public static void main (String[] args)
 	{
 		int x = 12;
 		float f = (float)100.50;
 		String s = "hello world";
 		
 		System.out.printf("Integer: %d\n" , x);
 		System.out.printf("Float Number: %f\n" , f);
 		System.out.printf("String: %s\n" , s);
 	}
 }