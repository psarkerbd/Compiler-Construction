/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		out dm = new out();
		
		String str = "Hello world ! This world is beautiful.";
		
		if(str.contains("world"))
		{
			dm.outS("\"world\" is contain on the main string\n");
		}
		
		if(str.contains("not"))
		{
			dm.outSn("\"not\" is contain on the main string");
		}
		
		else
		{
			dm.outSn("\"not\" is not contain on the main string");
		}
	}
}