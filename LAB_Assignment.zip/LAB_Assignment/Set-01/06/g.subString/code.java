/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		out dm = new out();
		
		String strM = "Hello world ! This world is beautiful";
		
		String str1 = strM.substring(14); // 14 is the index number, substring will be 14 to last of the string
		
		dm.outSn(str1);
		
		String str2 = strM.substring(0 , 11); // here strting index 1 and ending index 11
		
		dm.outS(str2);
	}
}