/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		out dem = new out();
		
		try
		{
			InputStreamReader inpreader = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(inpreader);
			String str1 = "" , str2 = "";
			
			dem.outS("Enter a String: ");
			str1 = br.readLine();
			
			dem.outS("Enter another String: ");
			str2 = br.readLine();
			
			dem.outS("You hae typed: ");
			String conS = str1.concat(str2);
			
			dem.outSn(conS);
			
		}catch(IOException ex)
		{
			dem.outSn("Problem occured");
		}
	}
}