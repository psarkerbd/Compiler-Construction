/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		out dm = new out();
		
		String Mstr = "Hello world! This world is beautiful!!!.";
		
		int len = 0;
		
		char [] ch = Mstr.toCharArray();
		
		for(char c : ch)
		{
			if(c == '!') len++;
		}
		
		//len -= 2;
		
		//len-=len;
		
		//dm.outnIn(len);
		
		if(len > 0)
		{
			String[] str = Mstr.split("!" , len+1);
			
			for(String tmp : str)
			{
				dm.outS(tmp);
			}
		}
		
		else
		{
			dm.outSn("\"!\" no contain in the Main String");
		}
	}
}