/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

class out
{
	void outS(String s)
	{
		System.out.print(s);
	}
	
	void outSn(String s)
	{
		System.out.println(s);
	}
	
	void outnIn(int n)
	{
		System.out.println(n);
	}
}

public class code
{
	public static void main (String[] args)
	{
		try
		{
			out dem = new out();
			InputStreamReader inpreader = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(inpreader);
			String str = "";
			
			dem.outS("Enter a String: ");
			
			str = br.readLine();
			
			
			dem.outS("You have typed: ");
			dem.outSn(str);
			dem.outS("Length: ");
			dem.outnIn(str.length());
			
			dem.outS("After triming your String is: ");
			
			str = str.trim();
			
			dem.outSn(str);
			dem.outS("Length: ");
			dem.outnIn(str.length());
			
		}catch(IOException ex)
		{
			System.out.printf("Problem Occured !");
		}
	}
}