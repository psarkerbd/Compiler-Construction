/*
*@Author: Pranta Sarker
*/

import java.util.*;

public class code
{
	public static void main(String [] args)
	{
		System.out.println("Hello World !");
	}
}