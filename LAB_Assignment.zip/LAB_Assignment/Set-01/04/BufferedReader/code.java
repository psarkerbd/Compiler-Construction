/*
*@Author: Pranta Sarker
*/

import java.util.*;
import java.io.*;

public class code
{
	public static void main(String [] args)
	{
		try 
		{
			InputStreamReader inpReader = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(inpReader);
			String str = "";
			System.out.print("Enter a String: ");
			str = br.readLine();
			System.out.println("You have typed " + str);
		}catch(IOException ex)
		{
			//ioe.printStachTrace();
			System.out.println("Problem Occured ");
		}
	}
}