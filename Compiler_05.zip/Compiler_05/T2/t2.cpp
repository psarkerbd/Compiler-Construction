#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    while(cin>>s)
       { string s2 ("Uddin");
         string s3 ("uddin");
         string s4 ("Begum");
         string s5 ("begum");
         size_t a1 = s.find(s2);
         size_t a2 = s.find(s3);
         size_t a3 = s.find(s4);
         size_t a4 = s.find(s5);
         if (a1!=string::npos || a2!=string::npos)
            cout << "Male" <<endl ;
       }
}
