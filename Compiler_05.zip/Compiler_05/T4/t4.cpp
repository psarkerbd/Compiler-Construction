#include <bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    while(cin>>s)
    {
        for(long i=0;i<s.size();i++)
        {
            if(s[i]=='(')
                cout<<"{";
            else if(s[i]==')')
                cout<<"}";
            else if(s[i]>='a' && s[i]<='z')
            {
                char n=toupper(s[i]);
                cout<<n;
            }
            else
                cout<<s[i];
        }
        cout<<endl;


    }
}
