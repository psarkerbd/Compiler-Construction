#include <bits/stdc++.h>

using namespace std;

int main()
{
string str;
cin >> str;

for(long i=0;i<str.length(); i++) {

if(str[i]=='(')
cout<<"{";

else if(str[i]==')')
cout<<"}";

else if(str[i]>='a' && str[i]<='z')
{
    char ch=toupper(str[i]);
    cout << ch;
}

else
cout << str[i];
}

//cout<<str[i];
}
