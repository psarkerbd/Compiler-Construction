#include<iostream>
using namespace std;

int main()
{
    string exp;
    getline(cin, exp);

    int i , len=0 , flag = 0 , in=0;
    char op;

    if(exp[0] >= '0' && exp[0] <= '9')
    {
        for(i=0; i<exp.length(); i++)
        {
            if(exp[i] == '+' || exp[i]=='-' || exp[i]=='*' || exp[i]=='/')
            {
                op = exp[i];
                flag = 1;
                in = i;
                //break;
            }

    }

    if(flag)
    {
        int x = 0 , y = 0;

        for(i=0; i<in; i++)
        {
            if(exp[i]>='0' && exp[i]<='9')
            {
                x = (exp[i] - 48) + (x * 10);
            }
        }

        //cout << x << "\n";

        for(i=in+1; i<exp.length(); i++)
        {
            if(exp[i]>='0' && exp[i]<='9')
            {
                y = (exp[i] - 48) + (y * 10);
            }
        }

        //cout << y << "\n";

        if(op == '+') cout << x + y << "\n";
        else if(op == '-') cout << x - y << "\n";
        else if(op == '*') cout << x * y << "\n";
        else if(op == '/') cout << x / y << "\n";
        else cout << "Invalid\n";
    }

    else
    {
        cout << "Invalid\n";
    }

    }

    else
    {
        cout << "Invalid\n";
    }

    return 0;
}
