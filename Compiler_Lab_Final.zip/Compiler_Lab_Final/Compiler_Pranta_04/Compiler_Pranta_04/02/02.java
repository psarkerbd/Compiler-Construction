/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */

import java.util.*;
import java.io.*;

public class name {
    public static void main(String [] args)
    {
        Scanner in  = new Scanner (System.in);
        
        String name = in.nextLine();
        
        name = name.toLowerCase();
        
        if(name.contains("begum"))
        {
            System.out.println("Female");
        }
        
        else if(name.contains("uddin"))
        {
            System.out.println("Male");
        }
    }
}
